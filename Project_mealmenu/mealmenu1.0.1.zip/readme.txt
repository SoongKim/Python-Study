# weekmenu 1.0.1

# weekmenu 1.0.0

해당 프로그램 실행 시, 이 주의 식단 메뉴를 menu.csv 파일에 저장합니다.
menu.csv 파일은 py 파일의 저장 위치와 동일한 디렉토리에 저장됩니다.
menu.csv는 ms949로 인코딩하였습니다. 엑셀 등 Windows 환경에서 이용 가능하십니다.
bs4, requests, pandas 모듈이 필요합니다.

해당 파일을 스케쥴러에 등록하시면, 매주 식단을 menu.csv로 저장하실 수 있으십니다.

##실행 오류 시

## 1. 해당 파일의 기본 드라이브는 C:입니다.
## 2. python.exe 파일의 기본 위치는 C:\Users\%username%\anaconda3\python.exe 입니다.

## 1.
python.exe 파일의 위치를 확인해주세요. Default value는 C:\Users\%username%\anaconda3\python.exe 입니다.
## 2.
py파일과 bat 파일을 바탕 화면에 위치시켜주세요. 결과물은 menu.csv로 바탕화면에 저장됩니다.


# weekmenu 1.0.1

UTF-8로 인코딩한 파일을 menuUTF.csv로 추가 생성합니다.
menuUTF 파일은 Python 환경에서 사용하실 수 있습니다.